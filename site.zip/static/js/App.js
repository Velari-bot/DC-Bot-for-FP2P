import React, { useEffect, useRef, useState } from 'react';
import { Routes, Route, useLocation, useNavigate, Navigate } from 'react-router-dom';

import AOS from "aos";
import "aos/dist/aos.css";

import Navbar from './components/Navbar/NavBar';
import Footer from './components/Footer/Footer';

import Index from './pages/index';
import BeginnerMasterclass from './pages/beginnerMasterclass';
import Coaching from './pages/coaching';
import IntermediateMasterclass from './pages/intermediateMasterclass';
import AdvancedMasterclass from './pages/advancedMasterclass';
import PaymentSuccess from "./pages/paymentSuccess"
import LoginSuccess from "./pages/loginSuccess"

const App = () => {
  const { pathname } = useLocation();
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    AOS.init({
      once: false,
      offset: 0,
      anchorPlacement: 'top-bottom',
    });
  }, []);

  return (
    <div className="min-h-screen w-full">
      <Navbar />
      <main className='min-h-[calc(100dvh-97px)]'>
        <Routes>
          {/* General Routes */}
          <Route path="/" element={<Index />} />
          <Route path="/beginner-masterclass" element={<BeginnerMasterclass />} />
          <Route path="/intermediate-masterclass" element={<IntermediateMasterclass />} />
          <Route path="/advanced-masterclass" element={<AdvancedMasterclass />} />
          <Route path="/coaching" element={<Coaching />} />

          <Route path="/payment-success" element={<PaymentSuccess />} />
          <Route path="/login-success" element={<LoginSuccess />} />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
};

export default App;