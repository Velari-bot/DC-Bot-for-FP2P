import { API_ROUTE, errorMessage } from "../utils/constants";

export const checkout = async (useMiddleware, productId=false) => {
    return await useMiddleware
        .post(`${API_ROUTE}/stripe/checkout?productId=${productId}`)
        .then((res) => res.data)
        .catch((err) => {
            console.log(err);
            return { error: true, message: errorMessage(err) };
        });
}