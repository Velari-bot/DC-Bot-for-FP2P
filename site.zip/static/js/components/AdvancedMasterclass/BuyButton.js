import React from "react";
import { ADVANCED_MONTHLY } from "../../utils/purchaceURLS";

const BuyButton = ({ text }) => {

    return (
        <>
            <a
                className="inline-block bg-gradient-to-r from-[#ff0000] to-red-500 text-black font-bold text-xl px-16 py-5 rounded-full hover:from-red-500 hover:to-[#ff0000] transition-all shadow-[0_0_20px_rgba(255,0,0,0.5)] hover:shadow-[0_0_30px_rgba(255,0,0,0.7)] transform hover:scale-105 duration-300"
                href={ADVANCED_MONTHLY}
                target="_blank"
            >
                {text}
            </a>

        </>
    )
}

export default BuyButton;
