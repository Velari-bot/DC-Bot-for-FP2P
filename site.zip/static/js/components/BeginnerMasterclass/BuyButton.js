import React from "react";
import { BEGINNER_MONTHLY } from "../../utils/purchaceURLS";

const BuyButton = ({ text }) => {

    return (
        <>
            <a
                className="inline-block bg-gradient-to-r from-[#00ff00] to-green-500 text-black font-bold text-xl px-16 py-5 rounded-full hover:from-green-500 hover:to-[#00ff00] transition-all shadow-[0_0_30px_rgba(0,255,0,0.5)] hover:shadow-[0_0_40px_rgba(0,255,0,0.7)] transform hover:scale-105 duration-300"
                href={BEGINNER_MONTHLY}
                target="_blank"
            >
                {text}
            </a>
        </>
    )
}

export default BuyButton;