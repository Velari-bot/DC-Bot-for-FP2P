import React from "react";

const included = [
    "/thumbnails/solos-gameplan.jpg",
    "/thumbnails/solos-endgames.jpg",
    "/thumbnails/fighting-tips.jpg",
    "/thumbnails/duos-gameplan.jpg",
    "/thumbnails/duo-endgames.jpg",
    "/thumbnails/mechanics-routine.jpg",
]

const WhatsIncluded = () => {

    return (
        <>
            <section className="pt-16 pb-10 px-4">
                <div className="max-w-6xl mx-auto">
                    <h2 className="text-4xl font-bold text-white text-center mb-12" data-aos="zoom-out">
                        What's Included
                    </h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                        {included.map((image, index) => (
                            <>
                                <img src={image} key={index} alt="" className="aspect-video w-full h-full rounded-md" data-aos="zoom-in"/>
                            </>
                        ))}
                    </div>

                    <p className="text-gray-400 text-center text-lg" data-aos="zoom-in">
                        And much more
                    </p>
                </div>
            </section>
        </>
    )
}

export default WhatsIncluded;