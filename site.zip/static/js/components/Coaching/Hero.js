import React, { useState } from "react";
import ReactPlayer from "react-player";
import { CheckIcon, UserIcon, UsersIcon, Trophy, Crown } from "lucide-react"
import { checkout } from "../../api/coaching";
import useMiddleware from "../../utils/useMiddleware";


const Hero = () => {
    const middleware = useMiddleware();
    const [creating, setCreating] = useState(false);

    const createCheckoutGroup = async () => {
        if (creating) return;
        setCreating(true);

        const response = await checkout(middleware, "group_coaching");
        if (response?.error) return setCreating(false);

        const checkoutUrl = response?.checkoutUrl;
        if (!checkoutUrl) return setCreating(false);

        window.location.href = checkoutUrl;
    }

    const createCheckoutSingle = async () => {
        if (creating) return;
        setCreating(true);

        const response = await checkout(middleware, "single_coaching");
        if (response?.error) return setCreating(false);

        const checkoutUrl = response?.checkoutUrl;
        if (!checkoutUrl) return setCreating(false);

        window.location.href = checkoutUrl;
    }

    const createCheckoutTier1 = async () => {
        if (creating) return;
        setCreating(true);

        const response = await checkout(middleware, "basic_season");
        if (response?.error) return setCreating(false);

        const checkoutUrl = response?.checkoutUrl;
        if (!checkoutUrl) return setCreating(false);

        window.location.href = checkoutUrl;
    }

    const createCheckoutTier2 = async () => {
        if (creating) return;
        setCreating(true);

        const response = await checkout(middleware, "advanced_season");
        if (response?.error) return setCreating(false);

        const checkoutUrl = response?.checkoutUrl;
        if (!checkoutUrl) return setCreating(false);

        window.location.href = checkoutUrl;
    }

    const oneOnOneBenefits = [
        'Find bad habits that hold you back',
        'Build a custom surgeplan or gameplan',
        'VOD Review my games and yours',
    ];
    const groupBenefits = [
        'Ask me any question you want',
        'Learn and improve together',
        'VOD Review my games and yours',
    ];
    const seasonalTier1Benefits = [
        'VOD Review once a week',
        'Weekly Private 1-on-1 calls',
        'Personalized gameplan'
    ];
    const seasonalTier2Benefits = [
        'Full VOD breakdown of every tournament',
        'Daily Private 1-on-1 calls',
        'Personalized strategy, game plan, and loot routes',
        'Custom development plan focused on your goals'
    ];

    return (
        <>
            <section className="pt-20 pb-16 px-4 relative min-h-[100%]">
                {/* Texture Overlay */}
                <div className="absolute inset-0 opacity-30 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00em0wLTMwYzAtMi4yMS0xLjc5LTQtNC00cy00IDEuNzktNCA0IDEuNzkgNCA0IDQgNC0xLjc5IDQtNHpNNiAzNGMwLTIuMjEtMS43OS00LTQtNHMtNCAxLjc5LTQgNCAxLjc5IDQgNCA0IDQtMS43OSA0LTR6bTAtMzBjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00ek0zNiA2NGMwLTIuMjEtMS43OS00LTQtNHMtNCAxLjc5LTQgNCAxLjc5IDQgNCA0IDQtMS43OSA0LTR6TTYgNjRjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00eiIvPjwvZz48L2c+PC9zdmc+')]"></div>

                <div className="max-w-6xl mx-auto text-center relative z-12">
                    <div className="max-w-4xl mx-auto text-center">
                        <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
                            Coaching
                            <span className="block text-[var(--yellow)] mt-2">1:1 & Group Coaching</span>
                        </h1>
                        <p className="text-gray-300 text-lg md:text-xl mb-12 max-w-2xl mx-auto">
                            Get personalized coaching from a proven competitor. Whether you
                            want 1:1 attention or prefer learning in a group, we have the
                            perfect option for you.
                        </p>
                    </div>

                    {/* Responsive video container */}
                    <div className="relative w-full max-w-4xl mx-auto rounded-xl overflow-hidden shadow-2xl border border-[#FACC24]/20  mt-5" data-aos="fade-up">
                        <div className="aspect-video">
                            <ReactPlayer
                                src="https://www.youtube.com/watch?v=XeW5mYlIaLA"
                                width="100%"
                                height="100%"
                                controls
                                playing={true}
                                className="rounded-xl"
                            />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none"></div>
                    </div>

                    {/* Coaching Options */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto mt-14">
                        {/* Group Coaching */}
                        <div className="bg-white/5 backdrop-blur-sm border border-white/20 rounded-2xl p-8 flex flex-col justify-between" data-aos="fade-up">
                            <div>
                                <div className="absolute top-4 right-4 bg-white/10 text-white p-2 rounded-full">
                                    <UsersIcon size={20} />
                                </div>
                                <div className="mb-6">
                                    <h3 className="text-white text-3xl font-bold mb-2">
                                        Group Coaching
                                    </h3>
                                    <p className="text-gray-300 text-sm mb-4">
                                        Join a private call with other passionate, competitive players who share simular goals.
                                    </p>
                                    <div className="flex items-baseline gap-2">
                                        <span className="text-[var(--yellow)] text-5xl font-bold">
                                            $30
                                        </span>
                                        <span className="text-gray-400">/session</span>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <button
                                    className="inline-block w-full bg-white/10 hover:bg-white/20 text-white font-bold text-lg px-8 py-4 rounded-xl border border-white/20 transition-all transform hover:scale-105 shadow-[0_0_10px_rgba(255,255,255,0.15)] hover:shadow-[0_0_25px_rgba(255,255,255,0.3)] duration-300 mb-6"
                                    onClick={() => createCheckoutGroup()}
                                >
                                    Join Group Coaching
                                </button>
                                <div className="space-y-3">
                                    {groupBenefits.map((benefit, index) => <div key={index} className="flex items-start gap-2">
                                        <CheckIcon className="text-[var(--yellow)] flex-shrink-0 mt-0.5" size={18} />
                                        <span className="text-gray-300 text-sm">{benefit}</span>
                                    </div>)}
                                </div>
                            </div>
                        </div>

                        {/* 1:1 Coaching */}
                        <div className="bg-gradient-to-br from-[#FACC24]/20 to-yellow-400/10 backdrop-blur-sm border-2 border-[var(--yellow)] rounded-2xl p-8 relative overflow-hidden flex flex-col justify-between" data-aos="fade-up">
                            <div>
                                <div className="absolute top-4 right-4 bg-[var(--yellow)] text-black p-2 rounded-full">
                                    <UserIcon size={20} />
                                </div>
                                <div className="mb-6">
                                    <h3 className="text-white text-3xl font-bold mb-2">
                                        1:1 Coaching
                                    </h3>
                                    <p className="text-gray-300 text-sm mb-4">
                                        A full hour where my entire focus is on fixing your bad habits and creating better ones.
                                    </p>
                                    <div className="flex items-baseline gap-2">
                                        <span className="text-[var(--yellow)] text-5xl font-bold">
                                            $150
                                        </span>
                                        <span className="text-gray-400">/hour</span>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <button className="block w-full bg-gradient-to-r from-[var(--yellow)] to-yellow-400 text-black font-bold text-lg px-8 py-4 rounded-xl hover:from-yellow-400 hover:to-[var(--yellow)] transition-all duration-300 shadow-[0_0_20px_rgba(250,204,36,0.3)] hover:shadow-[0_0_30px_rgba(250,204,36,0.5)] transform hover:scale-105 mb-6"
                                    onClick={() => createCheckoutSingle()}
                                >
                                    Book 1:1 Session
                                </button>
                                <div className="space-y-3">
                                    {oneOnOneBenefits.map((benefit, index) => <div key={index} className="flex items-start gap-2">
                                        <CheckIcon className="text-[var(--yellow)] flex-shrink-0 mt-0.5" size={18} />
                                        <span className="text-gray-300 text-sm">{benefit}</span>
                                    </div>)}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Seasonal Coaching Options */}
                    <div className="max-w-5xl mx-auto mt-16">
                        <h2 className="text-3xl md:text-4xl font-bold text-white mb-8 text-center" data-aos="fade-up">
                            Seasonal Coaching{' '}
                            <span className="text-[#FACC24]">(2 Months)</span>
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* Tier 1 - $500 */}
                            <div className="bg-black/40 backdrop-blur-sm border border-white/10 rounded-2xl p-8 hover:border-[#FACC24]/50 transition-all relative overflow-hidden group" data-aos="fade-up">
                                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#FACC24] to-transparent opacity-50 group-hover:opacity-100 transition-opacity"></div>
                                <div className="absolute top-4 right-4 bg-white/10 text-[#FACC24] p-2 rounded-full">
                                    <Trophy size={20} />
                                </div>
                                <div className="mb-6">
                                    <h3 className="text-white text-2xl font-bold mb-2">
                                        Basic
                                    </h3>
                                    <p className="text-gray-400 text-sm mb-4">
                                        Consistent weekly guidance to keep you on track
                                        throughout the season.
                                    </p>
                                    <div className="flex items-baseline gap-2">
                                        <span className="text-[#FACC24] text-4xl font-bold">
                                            $500
                                        </span>
                                        <span className="text-gray-400 text-sm">/season</span>
                                    </div>
                                </div>
                                <button
                                    className="inline-block w-full bg-white/10 hover:bg-white/20 text-white font-bold text-lg px-8 py-4 rounded-xl border border-white/20 transition-all transform hover:scale-105 shadow-[0_0_10px_rgba(255,255,255,0.15)] hover:shadow-[0_0_25px_rgba(255,255,255,0.3)] duration-300 mb-6"
                                    onClick={() => createCheckoutTier1()}
                                >
                                    Buy Now
                                </button>
                                <div className="space-y-3">
                                    {seasonalTier1Benefits.map((benefit, index) => <div key={index} className="flex items-start gap-2">
                                        <CheckIcon className="text-[#FACC24] flex-shrink-0 mt-0.5" size={18} />
                                        <span className="text-gray-300 text-sm">
                                            {benefit}
                                        </span>
                                    </div>)}
                                </div>
                            </div>

                            {/* Tier 2 - $2500 */}
                            <div className="bg-gradient-to-b from-[#FACC24]/10 to-black/60 backdrop-blur-sm border border-[#FACC24]/30 rounded-2xl p-8 hover:border-[#FACC24] transition-all relative overflow-hidden shadow-lg shadow-[#FACC24]/5" data-aos="fade-up">
                                <div className="absolute top-4 right-4 bg-[#FACC24] text-black p-2 rounded-full">
                                    <Crown size={20} />
                                </div>
                                <div className="mb-6">
                                    <h3 className="text-white text-2xl font-bold mb-2">
                                        Advanced
                                    </h3>
                                    <p className="text-gray-300 text-sm mb-4">
                                        The ultimate coaching experience. Daily access and full
                                        tournament analysis.
                                    </p>
                                    <div className="flex items-baseline gap-2">
                                        <span className="text-[#FACC24] text-4xl font-bold">
                                            $2,500
                                        </span>
                                        <span className="text-gray-400 text-sm">/season</span>
                                    </div>
                                </div>
                                <button
                                    className="block w-full bg-gradient-to-r from-[var(--yellow)] to-yellow-400 text-black font-bold text-lg px-8 py-4 rounded-xl hover:from-yellow-400 hover:to-[var(--yellow)] transition-all duration-300 shadow-[0_0_20px_rgba(250,204,36,0.3)] hover:shadow-[0_0_30px_rgba(250,204,36,0.5)] transform hover:scale-105 mb-6"
                                    onClick={() => createCheckoutTier2()}
                                >
                                    Buy Now
                                </button>
                                <div className="space-y-3">
                                    {seasonalTier2Benefits.map((benefit, index) => <div key={index} className="flex items-start gap-2">
                                        <CheckIcon className="text-[#FACC24] flex-shrink-0 mt-0.5" size={18} />
                                        <span className="text-gray-300 text-sm">
                                            {benefit}
                                        </span>
                                    </div>)}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section >
        </>
    )
}

export default Hero;