import React from "react";

import SingleBuyButton from "./SingleBuyButton";
import GroupBuyButtonGrey from "./GroupBuyButtonGrey";

const Promo = () => {

    return (
        <>
            <section className="py-16 px-4">
                <div className="max-w-4xl mx-auto text-center">
                    <div data-aos="fade-up">
                        <h2 className="text-4xl md:text-5xl font-bold text-white mb-4" data-aos="fade-up">
                            Ready to Get Help from Pro with Years of Experience?
                        </h2>
                        <p className="text-gray-300 text-xl mt-3 mb-8 max-w-2xl mx-auto" data-aos="fade-up">
                            Book now to get advise that makes a difference.
                        </p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <div data-aos="fade-right">
                            <GroupBuyButtonGrey text={"Join Group Coaching"} />
                        </div>
                        <div data-aos="fade-left">
                            <SingleBuyButton text={"Book 1:1 Coaching"} />
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default Promo;