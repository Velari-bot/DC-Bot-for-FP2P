import React from "react";
import Achievement from "./Achievement";

const achievements = [
    {
        name: "FNCS Grand Finals",
        image: "/achievements/1.png",
        link: "https://fortnitetracker.com/events/epicgames_S28_FNCS_Major1_GrandFinals_EU?window=S28_FNCS_Major1_GrandFinalDay2_EU&sm=S28_FNCS_Major1_GrandFinalDay2_CumulativeLeaderboardDef&page=0#14"
    },
    {
        name: "FNCS Grand Finals",
        image: "/achievements/4.png",
        link: "https://fortnitetracker.com/events/epicgames_S29_FNCS_Major2_GrandFinals_EU?window=S29_FNCS_Major2_GrandFinalDay2_EU&sm=S29_FNCS_Major2_GrandFinalDay2_CumulativeLeaderboardDef&page=0#17"
    },
    {
        name: "FNCS Grand Finals",
        image: "/achievements/2.png",
        link: "https://fortnitetracker.com/events/epicgames_S30_FNCS_Major3_GrandFinals_EU?window=S30_FNCS_Major3_GrandFinalDay2_EU&sm=S30_FNCS_Major3_GrandFinalDay2_CumulativeLeaderboardDef&page=0#27"
    },
    {
        name: "FNCS Grand Finals",
        image: "/achievements/3.png",
        link: "https://fortnitetracker.com/events/epicgames_S25_FNCS_Major3_GrandFinals_EU?window=S25_FNCS_Major3_GrandFinals_EU_Day1&sm=S25FNCS_GrandFinalsFloatingLeaderboardDef&page=0#30"
    },
    {
        name: "FNCS Division 1 Finals",
        image: "/achievements/5.png",
        link: "https://fortnitetracker.com/events/epicgames_S37_FNCSDivisionalCup_Division1_EU?window=S37_FNCSDivisionalCup_Division1_Week3Final_EU&page=0#4"
    },
    {
        name: "Performance Evaluation Finals",
        image: "/achievements/6.png",
        link: "https://fortnitetracker.com/events/epicgames_S26_PerfEvaluation_EU?window=S26_PerfEvaluation_EU_Event2_Round2&page=0#1"
    },
    {
        name: "Performance Evaluation Finals",
        image: "/achievements/7.png",
        link: "https://fortnitetracker.com/events/epicgames_S25_PerfEvaluation_EU?window=S25_PerfEvaluation_EU_Event1_Round2&page=0#1"
    },
    {
        name: "FNCS Showdown",
        image: "/achievements/8.png",
        link: "https://fortnitetracker.com/events/epicgames_S35_FNSCShowdown_EU?window=S35_FNCSShowdown_Event3Round2_EU&page=0#2"
    },
    {
        name: "FNCS Showdown",
        image: "/achievements/9.png",
        link: "https://fortnitetracker.com/events/epicgames_S35_FNSCShowdown_EU?window=S35_FNCSShowdown_Event2Round2_EU&page=0#5"
    },
    {
        name: "Solo Cash Cup",
        image: "/achievements/10.png",
        link: "https://fortnitetracker.com/events/epicgames_S34_SoloCashCup_EU?window=S34_SoloCashCup_Event1Round2_EU&page=0#11"
    }
]

const Achievements = () => {
    return (
        <>
            <section className="py-16 px-4">
                <div className="max-w-6xl mx-auto">
                    <div className="w-full flex justify-center items-center">
                        <a
                            className="text-4xl font-bold text-white text-center mb-12 hover:text-[var(--yellow)] transition-all duration-300 relative inline-block group/title"
                            href={"https://fortnitetracker.com/profile/all/38489ae208f44f53b3a790e922ed967d/events"}
                            target="_blank"
                            data-aos="zoom-out"
                        >
                            Deckzee's Achievements
                            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[var(--yellow)] transition-all duration-300 group-hover/title:w-full"></span>
                        </a>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {achievements.map((achievement, index) => (
                            <Achievement
                                key={index}
                                name={achievement.name}
                                image={achievement.image}
                                link={achievement.link}
                            />
                        ))}
                    </div>
                </div>
            </section>
        </>
    )
}

export default Achievements