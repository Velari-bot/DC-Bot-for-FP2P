import React, { useState } from "react";
import FAQ from "./FAQ";

const FAQs = () => {
    const [openIndex, setOpenIndex] = useState(null);

    const faqItems = [
        {
            question: 'What makes these Masterclasses different than others?',
            answer: "Deckzee is a Pro Fortnite player who have went through all levels in his career. This means he knows exactly what you need to do to get to the next level. Every video inside each masterclass will get updated after every important meta change. You also get invited to a private friendgroup that have the same achievements as you which you can't find anywhere else."
        },
        {
            question: "What if I don't think the masterclass is useful?",
            answer: "You can always cancel your subscription if you don't believe the masterclass is worth it for you. Deckzee also recommends you to give him feedback on why it wasn't for you so he can make sure you don't experience this again."
        },
        {
            question: 'Will each masterclass get updated?',
            answer: 'Every video in every masterclass gets updated after a new meta change or even a simple update depending on how much it changes the strategies that are being shared in each masterclass. You will always be prepared for new things before queuing into your next tournament.'
        },
        {
            question: "Can I buy the advanced Masterclass even if I don't have 10K pr?",
            answer: "You can buy any masterclass you want. You just won't be able to join the friendgroups if you don't have the required PR. When you reach the PR that is required you can then join the friendgroup."
        },
        {
            question: 'What is different from each masterclass?',
            answer: "Every masterclass is designed for that level. This means if you have 100 pr the Intermediate masterclass might be too hard for your understanding and it won't be as effective. Deckzee has made sure every gameplan and strategy fits the PR range as perfect as possible."
        },
        {
            question: 'What happens after this season?',
            answer: 'Deckzee will update every masterclass so it fits the next season. He will make sure you have all the tools you need to place every season consistently throughout your career. In other words he will be with you through all steps of your career all the way to the end of you achieving your goals.'
        },
        {
            question: 'Will you add more content?',
            answer: 'Deckzee will keep adding content that he believes is important for the players at each level. You can give feedback to him and give ideas to what he could add if you believe something fits the masterclass.'
        }
    ];

    const toggleFAQ = (index) => {
        setOpenIndex(openIndex === index ? null : index);
    };
    return (
        <>
            <section className="py-16 px-4">
                <div className="max-w-4xl mx-auto">
                    <h2 className="text-4xl md:text-5xl font-bold text-white text-center mb-4" data-aos="fade-down">
                        Frequently Asked Questions
                    </h2>
                    <p className="text-gray-400 text-center text-lg mb-12" data-aos="fade-up">
                        Everything you need to know about our masterclasses
                    </p>

                    <div className="space-y-4">
                        {faqItems.map((item, index) => (
                           <FAQ 
                           key={index}
                           question={item.question}
                           answer={item.answer}
                           index={index}
                           openIndex={openIndex}
                           onClick={() => toggleFAQ(index)}
                           />
                        ))}
                    </div>
                </div>
            </section>
        </>
    )
}

export default FAQs