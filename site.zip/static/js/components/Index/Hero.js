import React from "react";
import ReactPlayer from "react-player";
import { Link, useLocation } from 'react-router-dom'

const pfps = [
    "/pfps/deckzee.png",
    "/pfps/diegoplayz.png",
    "/pfps/higgs.png",
    "/pfps/kal.png",
    "/pfps/oliverog.png",
    "/pfps/blake.png",
]

const Hero = () => {
    return (
        <section className="pt-20 pb-16 px-4 relative min-h-[100%]">
            {/* Texture Overlay */}
            <div className="absolute inset-0 opacity-30 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00em0wLTMwYzAtMi4yMS0xLjc5LTQtNC00cy00IDEuNzktNCA0IDEuNzkgNCA0IDQgNC0xLjc5IDQtNHpNNiAzNGMwLTIuMjEtMS43OS00LTQtNHMtNCAxLjc5LTQgNCAxLjc5IDQgNCA0IDQtMS43OSA0LTR6bTAtMzBjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00ek0zNiA2NGMwLTIuMjEtMS43OS00LTQtNHMtNCAxLjc5LTQgNCAxLjc5IDQgNCA0IDQtMS43OSA0LTR6TTYgNjRjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00eiIvPjwvZz48L2c+PC9zdmc+')]"></div>

            <div className="max-w-6xl mx-auto text-center relative z-10">
                <h1 className="text-4xl md:text-7xl font-bold mb-12 leading-tight" data-aos="fade-down">
                    <span className="text-white block">Welcome to</span>
                    <span className="block text-[var(--yellow)] mt-2">Fortnite Path To Pro</span>
                </h1>

                {/* Responsive video container */}
                <div className="relative w-full max-w-4xl mx-auto rounded-xl overflow-hidden shadow-2xl border border-[#FACC24]/20" data-aos="fade-up">
                    <div className="aspect-video">
                        <ReactPlayer
                            src="https://www.youtube.com/watch?v=FOfMXz-vBd44"
                            width="100%"
                            height="100%"
                            controls
                            playing={true}
                            className="rounded-xl"
                        />
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none"></div>
                </div>

                <div className="flex flex-col items-center gap-4 max-w-md mx-auto mt-14">
                    <div className="flex -space-x-8" data-aos="fade-up">
                        {pfps.map((pfp, index) => (
                            <img
                                key={index}
                                src={pfp}
                                alt="Player"
                                className="w-14 h-14 rounded-full border-3 border-black"
                            />
                        ))}
                        <div className="w-14 h-14 rounded-full border-3 border-white bg-gray-800 flex items-center justify-center">
                            <span className="text-white text-2xl font-bold">+</span>
                        </div>
                    </div>
                    <div className="w-full flex" data-aos="fade-up">
                        <Link

                            to={`/beginner-masterclass`}
                            className="mt-4 w-full bg-gradient-to-r from-[var(--yellow)] to-yellow-400 text-black font-bold text-xl px-12 py-5 rounded-full hover:from-yellow-400 hover:to-[var(--yellow)] transition-all duration-300 shadow-[0_0_30px_rgba(250,204,36,0.5)] hover:shadow-[0_0_40px_rgba(250,204,36,0.7)] transform hover:scale-105"
                        >Join Now</Link>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Hero;
