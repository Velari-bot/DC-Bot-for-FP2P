import React from 'react'
import { TrophyIcon, MedalIcon, AwardIcon, StarIcon } from 'lucide-react'
import PastClient from './PastClient'

const clients = [
    {
        name: "Higgs",
        description: "3x 2nd FNCS",
        pfp: "/pfps/higgs.png",
        link: "https://x.com/BatmanBugha"
    },
    {
        name: "KalGamer",
        description: "4x Duo FNCS Winner",
        pfp: "/pfps/kal.png",
        link: "https://x.com/realKalgamer710"
    },
    {
        name: "OliverOG",
        description: "11th Duo FNCS",
        pfp: "/pfps/oliverog.png",
        link: "https://x.com/OliverOG"
    },
    {
        name: "Blake",
        description: "3rd Trio FNCS",
        pfp: "/pfps/blake.png",
        link: "https://x.com/blakeps"
    }
]

const PastClients = () => {
    return (
        <section className="pt-16 pb-20 px-4">
            <div className="max-w-6xl mx-auto">
                <h2 className="text-5xl md:text-6xl font-bold text-center mb-4" data-aos="zoom-in">
                    <span className="text-white">Past </span>
                    <span className="text-[var(--yellow)]">Clients</span>
                </h2>
                <p className="text-gray-400 text-center mb-12 text-lg" data-aos="zoom-in">
                    Pro Players That I Have Coached
                </p>
                <div className="flex justify-center items-start gap-6 md:gap-8 flex-wrap">
                    {clients.map((client, index) => (
                        <PastClient
                            key={index}
                            name={client.name}
                            description={client.description}
                            pfp={client.pfp}
                            link={client.link}
                        />
                    ))}
                </div>
                <p className="text-gray-400 text-center mt-12 text-lg" data-aos="zoom-in">
                    And many more
                </p>
            </div>
        </section>
    )
}


export default PastClients