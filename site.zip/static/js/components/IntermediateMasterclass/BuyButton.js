import React from "react";
import { INTERMEDIATE_MONTHLY } from "../../utils/purchaceURLS";

const BuyButton = ({ text }) => {

    return (
        <>
            <a
                className="inline-block bg-gradient-to-r from-[#ff7800] to-orange-500 text-white font-bold text-xl px-16 py-5 rounded-full hover:from-orange-500 hover:to-[#ff7800] transition-all shadow-[0_0_30px_rgba(255,120,0,0.5)] hover:shadow-[0_0_40px_rgba(255,120,0,0.7)] transform hover:scale-105 duration-300"
                href={INTERMEDIATE_MONTHLY}
                target="_blank"
            >
                {text}
            </a>

        </>
    )
}

export default BuyButton;