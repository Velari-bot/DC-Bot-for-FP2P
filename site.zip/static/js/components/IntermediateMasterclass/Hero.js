import React from "react";
import ReactPlayer from "react-player";

import { INTERMEDIATE_MONTHLY, INTERMEDIATE_YEARLY } from "../../utils/purchaceURLS";

const Hero = () => {

    return (
        <>
            <section className="pt-20 pb-16 px-4 relative min-h-[100%]">
                {/* Texture Overlay */}
                <div className="absolute inset-0 opacity-30 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00em0wLTMwYzAtMi4yMS0xLjc5LTQtNC00cy00IDEuNzktNCA0IDEuNzkgNCA0IDQgNC0xLjc5IDQtNHpNNiAzNGMwLTIuMjEtMS43OS00LTQtNHMtNCAxLjc5LTQgNCAxLjc5IDQgNCA0IDQtMS43OSA0LTR6bTAtMzBjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00ek0zNiA2NGMwLTIuMjEtMS43OS00LTQtNHMtNCAxLjc5LTQgNCAxLjc5IDQgNCA0IDQtMS43OSA0LTR6TTYgNjRjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00eiIvPjwvZz48L2c+PC9zdmc+')]"></div>

                <div className="max-w-6xl mx-auto text-center relative z-10">
                    <div className="max-w-4xl mx-auto text-center" data-aos="fade-down">
                        <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
                            Intermediate Masterclass
                            <span className="block text-[var(--orange)] mt-2">1-10k PR</span>
                        </h1>
                        <p className="text-gray-300 text-lg md:text-xl mb-10 max-w-2xl mx-auto">
                            The masterclass that shares the best strategies used by pros in ways so you can implement them.
                        </p>
                    </div>

                    {/* Responsive video container */}
                    <div className="relative w-full max-w-4xl mx-auto rounded-xl overflow-hidden shadow-2xl border border-[#ff7800]/20  mt-5" data-aos="fade-up">
                        <div className="aspect-video">
                            <ReactPlayer
                                src="https://www.youtube.com/watch?v=QzdcDIUxlr8"
                                width="100%"
                                height="100%"
                                controls
                                playing={true}
                                className="rounded-xl"
                            />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none"></div>
                    </div>

                    {/* Pricing Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto mt-12">
                        {/* Monthly Plan */}
                        <div className="bg-white/5 backdrop-blur-sm border border-white/20 rounded-2xl p-8 flex flex-col justify-between" data-aos="fade-up">
                            <div className="text-center mb-6">
                                <h3 className="text-white text-2xl font-bold mb-2">
                                    Monthly
                                </h3>
                                <div className="flex items-baseline justify-center gap-2">
                                    <span className="text-[var(--orange)] text-5xl font-bold">
                                        $25
                                    </span>
                                    <span className="text-gray-400">/month</span>
                                </div>
                            </div>

                            <a
                                className="w-full bg-white/10 hover:bg-white/20 text-white font-bold text-lg px-8 py-4 rounded-xl border border-white/20 transition-all transform hover:scale-105 shadow-[0_0_10px_rgba(255,255,255,0.15)] hover:shadow-[0_0_25px_rgba(255,255,255,0.3)] duration-300"
                                href={INTERMEDIATE_MONTHLY}
                                target="_blank"
                            >
                                Buy Now
                            </a>
                        </div>

                        {/* Yearly Plan */}
                        <div className="bg-gradient-to-br from-[#ff7800]/20 to-orange-400/10 backdrop-blur-sm border-2 border-[var(--orange)] rounded-2xl p-8 relative overflow-hidden flex flex-col justify-between" data-aos="fade-up">
                            <div className="absolute top-4 right-4 bg-[var(--orange)] text-black text-xs font-bold px-3 py-1 rounded-full">
                                SAVE 17%
                            </div>

                            <div className="text-center mb-6">
                                <h3 className="text-white text-2xl font-bold mb-2">
                                    Yearly
                                </h3>

                                <div className="flex items-baseline justify-center gap-2">
                                    <span className="text-[var(--orange)] text-5xl font-bold">
                                        $250
                                    </span>
                                    <span className="text-gray-400">/year</span>
                                </div>

                                <p className="text-gray-300 text-lg mt-3 line-through opacity-80">
                                    Normal Price $300/year
                                </p>
                            </div>

                            <a
                                className="w-full bg-gradient-to-r from-[var(--orange)] to-orange-400 text-black font-bold text-lg px-8 py-4 rounded-xl hover:from-orange-400 hover:to-[var(--orange)] transition-all shadow-[0_0_30px_rgba(255,120,0,0.5)] hover:shadow-[0_0_40px_rgba(255,120,0,0.7)] transform hover:scale-105 duration-300"
                                href={INTERMEDIATE_YEARLY}
                                target="_blank"
                            >
                                Buy Now
                            </a>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default Hero;