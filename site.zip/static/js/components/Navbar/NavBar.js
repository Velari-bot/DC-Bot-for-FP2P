import React, { useEffect, useState, useRef } from 'react'
import { MenuIcon, XIcon } from 'lucide-react'
import { Link, useLocation } from 'react-router-dom'

const NavBar = () => {
    const [isOpen, setIsOpen] = useState(false)
    const [hoveredIndex, setHoveredIndex] = useState(null)
    const [activeIndex, setActiveIndex] = useState(0)
    const [underlineStyle, setUnderlineStyle] = useState({
        left: 0,
        width: 0,
    })

    const navLinksRef = useRef([])
    const navbarRef = useRef(null)
    const location = useLocation()

    const navLinks = [
        {
            name: 'Home',
            href: '',
        },
        {
            name: 'Beginner',
            subtitle: '0-1k PR',
            href: 'beginner-masterclass',
        },
        {
            name: 'Intermediate',
            subtitle: '1-10k PR',
            href: 'intermediate-masterclass',
        },
        {
            name: 'Advanced',
            subtitle: '10-50k PR',
            href: 'advanced-masterclass',
        },
        {
            name: 'Coaching',
            href: 'coaching',
        },
    ]

    // Make underline/active tab correct on initial load & route changes
    useEffect(() => {
        const currentPath = location.pathname.replace(/\/+$/, '') || '/'
        const foundIndex = navLinks.findIndex((link) => {
            const linkPath = link.href ? `/${link.href}` : '/'
            return linkPath === currentPath
        })
        setActiveIndex(foundIndex === -1 ? 0 : foundIndex)
    }, [location.pathname])

    useEffect(() => {
        const updateUnderline = () => {
            const index = hoveredIndex !== null ? hoveredIndex : activeIndex
            const element = navLinksRef.current[index]
            const navbar = navbarRef.current
            if (element && navbar) {
                const navbarRect = navbar.getBoundingClientRect()
                const elementRect = element.getBoundingClientRect()
                const offsetLeft = elementRect.left - navbarRect.left
                setUnderlineStyle({
                    left: offsetLeft + elementRect.width / 2 - 40,
                    width: 80,
                })
            }
        }

        updateUnderline()
        window.addEventListener('resize', updateUnderline)

        return () => {
            window.removeEventListener('resize', updateUnderline)
        }
    }, [hoveredIndex, activeIndex])

    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth > 1040) {
                setIsOpen(false)
            }
        }

        window.addEventListener('resize', handleResize)
        return () => window.removeEventListener('resize', handleResize)
    }, [])

    return (
        <nav
            ref={navbarRef}
            className="top-0 left-0 right-0 z-50 bg-gradient-to-r from-gray-800 via-[#070a0e] to-gray-800 backdrop-blur-md border-b border-white/30 relative py-2"
        >
            {/* Texture overlay */}
            <div className="absolute inset-0 opacity-10 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00eiIvPjwvZz48L2c+PC9zdmc+')] pointer-events-none"></div>

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
                <div className="flex items-center justify-between h-16">
                    {/* Logo and Brand */}
                    <Link
                        to="/"
                        className="flex items-center gap-2 flex-shrink-0 cursor-pointer transition-all duration-300 hover:opacity-60"
                    >
                        <img
                            src="/assets/logo.png"
                            alt="Fortnite Path To Pro Logo"
                            className="h-10 w-10"
                        />
                        <div className="flex flex-col">
                            <span className="text-white font-bold text-lg leading-tight">
                                Fortnite
                            </span>
                            <span className="text-white font-bold text-lg leading-tight">
                                Path To Pro
                            </span>
                        </div>
                    </Link>

                    {/* Desktop Navigation - Centered */}
                    <div className="hidden min-[1040px]:flex items-center absolute left-1/2 transform -translate-x-1/2">
                        {navLinks.map((link, index) => (
                            <React.Fragment key={link.name}>
                                {/* small vertical line between items */}
                                {index > 0 && (
                                    <div className="h-6 w-px bg-white/25 mx-1" />
                                )}

                                <Link
                                    ref={(el) => (navLinksRef.current[index] = el)}
                                    to={`/${link.href}`}
                                    className="relative px-6 py-2 text-center transition-colors w-[140px] h-[48px] flex items-center justify-center"
                                    onMouseEnter={() => setHoveredIndex(index)}
                                    onMouseLeave={() => setHoveredIndex(null)}
                                    onClick={() => setActiveIndex(index)}
                                >
                                    <div className="flex flex-col">
                                        <span className="text-white font-medium text-sm whitespace-nowrap">
                                            {link.name}
                                        </span>
                                        <span className="text-gray-400 text-xs whitespace-nowrap">
                                            {link.subtitle}
                                        </span>
                                    </div>
                                </Link>
                            </React.Fragment>
                        ))}
                    </div>

                    {/* Desktop Sign-In Button */}
                    <div className="hidden min-[1040px]:flex items-center">
                        <a className="bg-gradient-to-r from-[var(--yellow)] to-yellow-400 text-black font-bold text-sm px-6 py-2.5 rounded-lg hover:from-yellow-400 hover:to-[var(--yellow)] transition-all duration-300 shadow-[0_0_20px_rgba(250,204,36,0.3)] hover:shadow-[0_0_25px_rgba(250,204,36,0.5)] transform"
                            href={"http://masterclass.fortnitepathtopro.com/login"}
                            target={"_blank"}
                        >
                            Sign In
                        </a>
                    </div>

                    {/* Mobile Menu Button */}
                    <button
                        onClick={() => setIsOpen(!isOpen)}
                        className="text-white p-2 transition-transform duration-300 active:scale-95 min-[1040px]:hidden"
                    >
                        <div className="relative w-6 h-6">
                            <MenuIcon
                                size={24}
                                className={`absolute inset-0 transition-all duration-300 ${isOpen
                                        ? 'opacity-0 rotate-90 scale-0'
                                        : 'opacity-100 rotate-0 scale-100'
                                    }`}
                            />
                            <XIcon
                                size={24}
                                className={`absolute inset-0 transition-all duration-300 ${isOpen
                                        ? 'opacity-100 rotate-0 scale-100'
                                        : 'opacity-0 -rotate-90 scale-0'
                                    }`}
                            />
                        </div>
                    </button>
                </div>

                {/* Mobile Navigation */}
                <div
                    className={`[1040px]:hidden overflow-hidden transition-all duration-400 ease-in-out ${isOpen
                            ? 'max-h-[500px] opacity-100'
                            : 'max-h-0 opacity-0'
                        }`}
                >
                    <div className="pb-6">
                        {navLinks.map((link, index) => (
                            <Link
                                key={link.name}
                                to={`/${link.href}`}
                                className={`py-3 px-4 border-t border-white/10 rounded-lg transition-all duration-300 hover:translate-x-2 active:scale-[0.97] h-[70px] flex flex-col justify-center ${activeIndex === index
                                        ? 'text-white border-l-2 border-l-white'
                                        : 'text-gray-400'
                                    } ${isOpen
                                        ? 'translate-x-0 opacity-100'
                                        : '-translate-x-8 opacity-0'
                                    }`}
                                onClick={() => {
                                    setActiveIndex(index)
                                    setIsOpen(false)
                                }}
                            >
                                <div className="font-medium">{link.name}</div>
                                <div className="text-sm">
                                    {link.subtitle}
                                </div>
                            </Link>
                        ))}
                        <div
                            className={`border-t border-white/10 mt-2 transition-all duration-300 ${isOpen
                                    ? 'translate-x-0 opacity-100'
                                    : '-translate-x-8 opacity-0'
                                }`}
                        >
                            <a
                                className="w-full bg-gradient-to-r from-[var(--yellow)] to-yellow-400 text-black font-bold text-sm px-6 py-3 rounded-lg hover:from-yellow-400 hover:to-[var(--yellow)] transition-all duration-300 shadow-[0_0_20px_rgba(250,204,36,0.3)] hover:shadow-[0_0_25px_rgba(250,204,36,0.5)] transform"
                                href={"http://masterclass.fortnitepathtopro.com/login"}
                                target={"_blank"}
                            >
                                Sign In
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            {/* Underline */}
            <div
                className="absolute bottom-0 left-0 h-0.5 bg-white transition-all duration-300 ease-out hidden min-[1040px]:block"
                style={{
                    left: `${underlineStyle.left}px`,
                    width: `${underlineStyle.width}px`,
                }}
            />
        </nav>
    )
}

export default NavBar
