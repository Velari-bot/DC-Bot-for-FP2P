import React, { useEffect, useState, useRef } from "react";

import Hero from "../components/BeginnerMasterclass/Hero";
import WhatsIncluded from "../components/BeginnerMasterclass/WhatsIncluded";
import BuyButton from "../components/BeginnerMasterclass/BuyButton";
import AboutDeckzee from "../components/BeginnerMasterclass/AboutDeckzee";
import SneakPeek from "../components/BeginnerMasterclass/SneakPeek";

const BeginnerMasterclass = () => {
    useEffect(() => {
        document.title = "Beginner Masterclass | Fortnite Path To Pro";
    }, []);

    return (
        <>
            <div className="min-h-screen w-full relative bg-[#0A0A0A]">
                <div className="bg-gradient-to-b from-gray-800 via-black to-gray-800 relative">
                    <div className="absolute inset-0 opacity-20 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00em0wLTMwYzAtMi4yMS0xLjc5LTQtNC00cy00IDEuNzktNCA0IDEuNzkgNCA0IDQgNC0xLjc5IDQtNHpNNiAzNGMwLTIuMjEtMS43OS00LTQtNHMtNCAxLjc5LTQgNCAxLjc5IDQgNCA0IDQtMS43OSA0LTR6bTAtMzBjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00eiIvPjwvZz48L2c+PC9zdmc+')] pointer-events-none"></div>
                    <div className="relative px-5">
                        <Hero />
                    </div>
                    {/* Fade transition from gradient to dark color */}
                    <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-b from-transparent to-[#0A0A0A] pointer-events-none"></div>
                </div>

                <div className=" px-5">
                    <WhatsIncluded />

                    <div className="w-full flex justify-center items-center" data-aos="zoom-in">
                        <div>
                            <BuyButton text={"Join Today"} />
                        </div>
                    </div>

                    <AboutDeckzee />
                    <SneakPeek />

                    <div className="w-full flex justify-center items-center pb-10" data-aos="zoom-out">
                        <BuyButton text={"Get Started Today"} />
                    </div>
                </div>
            </div>
        </>
    );
};

export default BeginnerMasterclass;
