export const BEGINNER_MONTHLY = "http://masterclass.fortnitepathtopro.com/beginner-masterclass/buy";
export const BEGINNER_YEARLY = "http://masterclass.fortnitepathtopro.com/beginner-masterclass/buy";

export const INTERMEDIATE_MONTHLY = "http://masterclass.fortnitepathtopro.com/intermediate-masterclass/buy";
export const INTERMEDIATE_YEARLY = "http://masterclass.fortnitepathtopro.com/intermediate-masterclass/buy";

export const ADVANCED_MONTHLY = "http://masterclass.fortnitepathtopro.com/advanced-masterclass/buy";
export const ADVANCED_YEARLY = "http://masterclass.fortnitepathtopro.com/advanced-masterclass/buy";

export const SINGLE_COACHING = "";
export const GROUP_COACHING = "";