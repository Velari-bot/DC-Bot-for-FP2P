export const TIKTOK = "https://www.tiktok.com/@deckzee_main";
export const TWITTER = "https://x.com/DeckzeeMain"
export const YOUTUBE = "https://www.youtube.com/@deckzee"
export const TWITCH = "https://twitch.tv/deckzee"
export const DISCORD = "https://discord.gg/RUHGATkXf4"